import mongoose from "mongoose";

const movieSchema = new mongoose.Schema({
  title: String,
  genre: String,
  description: String,
  releaseYear: Number,
  posterUrl: String,
});

const Movie = mongoose.model("Movie", movieSchema);

// ✅ Export mặc định
export default Movie;
